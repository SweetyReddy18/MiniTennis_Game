import java.awt.*;

public class Ball {
	private static final int DIAMETER = 25;
	private int x;
	private int y;
	private int xspd;
	int yspd;
	public int finalScore;
	private MiniTennis game;
	public Ball(MiniTennis game) {
		this.game = game;
		xspd = 1;
		yspd = 1;
	}
	void move(){
		
		if (x + xspd < 0)//to check that ball doesn't go left
			xspd = game.speed;//right
		if (x + xspd > game.getWidth() - DIAMETER)//to check that ball doesn't go right
			xspd = -game.speed;//left
		if (y + yspd < 0)//to check that ball doesn't go up
			yspd = game.speed;//down
		if (y + yspd > game.getHeight() - DIAMETER) {
			game.speed = 1;
			//finalScore = game.speed;
			game.gameOver();
		}
		if (collision()) {
			yspd = -game.speed;//minus removed=>no collision b/w bar & ball
			y = game.bar.getY() - DIAMETER;
			//Graphics2D graphic = (Graphics2D);
			//graphic.drawString("Collision happened", 10, 30);
			game.speed++;
			finalScore=game.speed;//if not done, score does not increase.
		}
		x += xspd;
		y += yspd;//changes x, y speed respectively for the ball after collision
	}
	public void paint(Graphics2D g) {
		g.setColor(Color.red);
		g.fillOval(x, y, DIAMETER, DIAMETER);
	}
	
	public Rectangle getBounds() {
		return new Rectangle(x,y, DIAMETER, DIAMETER);
	}
	
	private boolean collision() {
		return game.bar.getBounds().intersects(getBounds());
	}
}
	