import java.awt.*;
//import java.applet.*;
import java.awt.event.*;
import javax.swing.*;

public class MiniTennis extends JPanel{
	private static final long serialVersionUID = 1L;
	Bar bar = new Bar(this);
	Ball ball = new Ball(this);
	int speed = 1;
	
	private int getScore() {
		return speed - 1 ;
	}
	public MiniTennis() {
		addKeyListener(new KeyListener() {
			public void keyTyped(KeyEvent e) {
				
			}
			public void keyPressed(KeyEvent e) {
				bar.keyPressed(e);
			}
	
			public void keyReleased(KeyEvent e) {
				bar.keyReleased(e);
			}
		});
		setFocusable(true);
	}
	public static void main(String[] args) throws InterruptedException {
		MiniTennis miniT = new MiniTennis();
		JFrame frame = new JFrame();
		frame.add(miniT);
		frame.setSize(400, 600);
		frame.setVisible(true);
		frame.setTitle("DX-BALL game");
		frame.setLayout(new CardLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		while (true) {
			miniT.move();
			miniT.repaint();
			Thread.sleep(10);
		}
	}
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D graphic = (Graphics2D) g;
		graphic.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		ball.paint(graphic);
		bar.paint(graphic);
		
		graphic.setColor(Color.BLUE);
		graphic.setFont(new Font("Courier", Font.BOLD, 30));
		graphic.drawString("Score: " + String.valueOf(getScore()), 10, 30);
		setBackground(Color.cyan);
		if(getScore() >= 2 && getScore() < 4){
			setBackground(Color.black);
			bar.WIDTH = 130;
		}
		else if (getScore() >= 4 && getScore() < 6){
			setBackground(Color.yellow);
			bar.WIDTH = 120;
		}
		else if (getScore() >= 6 && getScore() < 8){
			setBackground(Color.green);
			bar.WIDTH = 100;
		}
		else if (getScore() >= 8){
			setBackground(Color.pink);
			bar.WIDTH = 90;
		}
	}
	private void move() {
		ball.move();
		bar.move();
	}
	public void gameOver() {
		String str = null;
		if (ball.finalScore == 0){
			str = "Your final score: 0 ";
		}
		else if(ball.finalScore >= 1){
			str = "Your final score: " + (ball.finalScore-1);
		}
		int n = JOptionPane.showConfirmDialog(
			    this,str+
			    "\nWould you like to play again?", "Game Over",
			    JOptionPane.YES_NO_OPTION);
		if (n == JOptionPane.YES_OPTION) {
			ball.yspd = -1;
		}
		else {
			System.exit(ABORT);
		}
	}
}