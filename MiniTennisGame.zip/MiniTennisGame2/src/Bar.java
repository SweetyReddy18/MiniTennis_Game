import java.awt.*;
import java.awt.event.*;

public class Bar {
	private static final int Y = 500;
	public int WIDTH = 150;
	private static final int HEIGHT = 15;
	
	private MiniTennis miniT;
	private int x;
	private int xspd;
	public Bar(MiniTennis miniT) {
		this.miniT = miniT;
	}
	public void move() {
		if (x + xspd > 0 && x + xspd < miniT.getWidth()- WIDTH)
			x = x + 2*xspd;
	}

	public void paint(Graphics2D g) {
		g.setColor(Color.magenta);
		g.fillRect(x, Y, WIDTH, HEIGHT);
	}

	public void keyReleased(KeyEvent e) {
		xspd = 0;
	}

	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_LEFT)
			xspd = -miniT.speed;
		if (e.getKeyCode() == KeyEvent.VK_RIGHT)
			xspd = miniT.speed;
	}
	public Rectangle getBounds() {
		return new Rectangle(x, Y, WIDTH, HEIGHT);
	}
	
	public int getY() {
		return Y;
	}
}